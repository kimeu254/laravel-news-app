<div class="row">
    <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="con">
                <img src="/storage/posts/<?php echo e($news->image); ?>" alt="" class="img-fluid w-100" style="height: 250px; object-fit: cover;">
            </div>
            <div class="py-3">
                <a href="<?php echo e(route('sports.show',$news->headline)); ?>" class="headline h5" style="">
                    <?php echo e($news->headline); ?>

                </a>
                <div class="d-flex">
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <?php if($author->id == $news->posted_by): ?>
                        <a class="headline" href="<?php echo e(route('author.show',$author->first_name)); ?>" style="font-weight: 700; font-size:x-small">Author: <?php echo e($author->first_name); ?> <?php echo e($author->last_name); ?> </a> 
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="px-2">
                        <small style="font-weight:100; font-size: xx-small;"><?php echo e(\Carbon\Carbon::parse($news->created_at)->toRfc850String()); ?></small>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\Laravel\test-app\resources\views/public/categories/sports/data.blade.php ENDPATH**/ ?>
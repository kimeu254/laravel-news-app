

<?php $__env->startSection('content'); ?>
<div>
    <div class="container">
        <div class="py-3">
            <h6 style="color: gray; font-size: x-small;">News <small>/</small> International</h6>
        </div>
        <div class="row">
            <div class="col-md-8">
                <div>
                    <h1 style="font-weight: bolder;"><?php echo e($international->headline); ?></h1>
                </div>
                <div class="d-flex">
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <?php if($author->id == $international->posted_by): ?>
                        <a class="headline" href="<?php echo e(route('author.show',$author->first_name)); ?>" style="font-weight: 700; font-size:x-small">Author: <?php echo e($author->first_name); ?> <?php echo e($author->last_name); ?> </a> 
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="px-2">
                        <small style="font-weight:100; font-size: xx-small;"><?php echo e(\Carbon\Carbon::parse($international->created_at)->toRfc850String()); ?></small>
                    </div>
                </div>                                         
                <div class="py-3">
                    <div class="con">
                        <img src="/storage/posts/<?php echo e($international->image); ?>" class="img-fluid w-100" style="height: 500px;">
                    </div>
                </div>
                <div class="py-3">
                    <p class="h6" style="white-space: pre-wrap;"><?php echo e($international->story); ?></p>
                </div>
                <div class="py-3">
                    <div class="con">
                        <img src="/storage/posts/<?php echo e($international->image_one); ?>" class="img-fluid w-100" style="height: 500px;">
                    </div>
                </div>
                <div class="py-3">
                    <p class="h6" style="white-space: pre-wrap;"><?php echo e($international->story_one); ?></p>
                </div>
                <?php if($international->url != null): ?>
                    <div class="py-3">
                        <div class="embed-responsive ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/<?php echo e($international->url); ?>" frameborder="0"></iframe>
                        </div>
                    </div>
                 <?php endif; ?>
                 <?php if($international->story_two != null): ?>
                    <div class="py-3">
                        <p class="h6" style="white-space: pre-wrap;"><?php echo e($international->story_two); ?></p>
                    </div>
                <?php endif; ?>
                <div class="py-3">
                    <h6 style="font-weight: bold;">Share:</h6>
                    <div class="">
                        
                            <a class="fa fa-facebook"></a>
                        
                        
                            <a class="fa fa-instagram"></a>
                        
                        
                            <a class="fa fa-twitter"></a>
                        
                        
                            <a class="fa fa-whatsapp"></a>
    
                    </div>
                </div>
                <div>
                    <h5 style="font-weight: bold;">Related Stories</h5>
                    <div class="row">
                        <?php $__currentLoopData = $internationalnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4" >
                            <div style="background: white;">
                                <div class="con">
                                    <img src="/storage/posts/<?php echo e($news->image); ?>" class="img-fluid w-100" style="height: 150px;">
                                </div>
                                <a href="<?php echo e(route('international.show',$news->headline)); ?>" class="h4 headline">
                                    <p class="p-2 h6"><?php echo e($news->headline); ?></p>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </div>
                </div>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
</div>

<style>
    .con {
      overflow: hidden;
    }
    .con img {
        object-fit: cover;
        display: block;
        transition: transform .4s;
    }
    .con img:hover {
        transform: scale(1.3);
        transform-origin: 50% 50%;
    }
    .title{
        font-weight: 900; 
        font-size: 30px;
        color: rgb(40, 116, 119);
        border: 1px solid #e7dee9;
        border-left: 5px solid #ff2942;
        margin-bottom: 10px;
    }
    .headline{
        font-weight:700;
        color: black;
        text-decoration: none;
    }
    .headline:hover{
        color: #ff2942;
    }
    .hidden {
        display: none;
    }
    .block {
        display: block;
    }
    
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\test-app\resources\views/public/news/international/view.blade.php ENDPATH**/ ?>
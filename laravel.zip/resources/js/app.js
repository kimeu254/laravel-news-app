import './bootstrap';
import './misc';
import './hoverable-collapse';
import './off-canvas';
import "mdi-icons/css/materialdesignicons.min.css";
import "font-awesome/css/font-awesome.min.css";
